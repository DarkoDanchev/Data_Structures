#include <iostream>

#include "Object.h" //for testing
#include "Furniture.h"
#include "Character.h"
#include "Drone.h"
#include "Position.h"
#include "Room.h"

using namespace std;

int main()
{
    cout << "Starting..." << endl;

    string a("Dar\nko");

    cout<<a<<endl;

    return 0;
}
