#include "Object.h"

class Character : public Object
{
private:
    char* name;
public:
    Character();
    Character(char*,int,int,const char*);
    Character(const Character&);
    Character& operator=(const Character&);
    const char* getName() const;
    void setName(const char*);
    int getID() const;
    ~Character();

};
