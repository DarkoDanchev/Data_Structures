#include "Furniture.h"

Furniture::Furniture() : Object()
{
    this->description = "";
}
Furniture::Furniture(const char* type,int x,int y, string description) : Object(type,x,y)
{
    this->description = description;
}
Furniture::Furniture(const Furniture& ft) : Object(ft)
{
    this->description = ft.getDescription();
}
Furniture& Furniture::operator=(const Furniture& ft)
{
    if(this != &ft)
    {
        Object::operator=(ft);
        this->description = ft.getDescription();
    }

    return *this;
}

//the getters
string Furniture::getDescription() const
{
    return this->description;
}
int Furniture::getID() const
{
    return 0;
}
//the setters
void Furniture::setDescription(string description)
{
    this->description = description;
}
Furniture::~Furniture()
{
    this->description = "";
}
