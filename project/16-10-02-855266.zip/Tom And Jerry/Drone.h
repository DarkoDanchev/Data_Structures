#include "Object.h"

class Drone : public Object
{
private:
    string owner;
public:
    Drone();
    Drone(string,int,int,const char*);
    Drone(const Drone&);
    Drone& operator=(const Drone&);
    string getOwner() const;
    void setOwner(const string&);
    int getID() const;
    ~Drone();

};
