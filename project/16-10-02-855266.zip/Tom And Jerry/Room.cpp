#include "Room.h"

Room::Room()
{
    this->widght = 0;
    this->height = 0;

    //setting up the empty array
    this->positions = new Position*[0];
    this->positions[0] = new Position[0];
}

Room::Room(int widght,int height,Position** positions)
{
    this->widght = widght;
    this->height = height;

    positions = new Position*[height];

    for(int i = 0; i < height; i++)
    {
        positions[i] = new Position[widght];
    }

    //this will be slow but is the only way to copy two dimensional array
    for(int i = 0; i < height; i++)
    {
        for(int j = 0; j < widght; j++)
        {
            this->positions[i][j] = positions[i][j];
        }
    }
}
//the copy function
void Room::copy(const Room& room)
{
    this->widght = room.getWidght();
    this->height = room.getHeight();

    this->positions = new Position*[height];

    for(int i = 0; i < this->height; i++)
        this->positions[i] = new Position[widght];

    for(int i = 0; i < room.getHeight(); i++)
    {
        for(int j = 0; j < room.getWidght(); j++)
        {
            this->positions[i][j] = room.getPosition(i,j);
        }
    }

}
//the copy constructor and the operator=
Room::Room(const Room& room)
{
    this->copy(room);
}
Room& Room::operator=(const Room& room)
{
    if(this != &room)
    {
        for(int i = 0; i < this->height; i++)
        {
            delete [] this->positions[i];
        }
        delete [] this->positions;

        copy(room);
    }

    return *this;
}
//the getters and the setters
int Room::getWidght() const
{
    return this->widght;
}
int Room::getHeight() const
{
    return this->height;
}
Position Room::getPosition(int x,int y) const
{
    return this->positions[x][y];
}
void Room::setWidght(int widght)
{
    this->widght = widght;
}
void Room::setHeight(int height)
{
    this->height = height;
}
void Room::setPositon(Position position,int x,int y)
{
    this->positions[x][y] = position;
}

//the destructor
Room::~Room()
{
    for(int i = 0; i < height; i++)
        delete this->positions[i];

    delete [] this->positions;
}
