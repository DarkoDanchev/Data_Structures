#include "Drone.h"


Drone::Drone() : Object() {} //the default constructor

Drone::Drone(string owner,int x ,int y, const char* type) : Object(type,x,y)
{
    this->owner = owner;
}
Drone::Drone(const Drone& dr) : Object(dr)
{
    this->owner = dr.getOwner();
}

Drone& Drone::operator=(const Drone& dr)
{
    if(this != &dr)
    {
        Object::operator=(dr);
        this->owner = dr.getOwner();
    }

    return *this;
}

string Drone::getOwner() const
{
    return this->owner;
}
void Drone::setOwner(const string& owner)
{
    this->owner = owner;
}
int Drone::getID() const
{
    return 2;
}
Drone::~Drone()
{
    this->owner = "";
}
