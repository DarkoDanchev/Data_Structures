#include "Character.h"


Character::Character() : Object()
{
    this->name = new char[0];
    strcpy(name,"");
}

Character::Character(char* type,int x,int y,const char* name) : Object(type,x,y)
{
    this->name = new char[strlen(name)];
    strcpy(this->name,name);
}
Character::Character(const Character& ct) : Object(ct)
{
    this->name = new char[strlen(ct.getName())];
    strcpy(this->name,ct.getName());
}
Character& Character::operator=(const Character& ct)
{
    if(this != &ct)
    {
        Object::operator=(ct);
        delete [] this->name;
        this->name = new char[strlen(ct.getName())];
        strcpy(this->name,ct.getName());
    }

	return *this;
}

//the getters
const char* Character::getName() const
{
    return this->name;
}
//the setters
void Character::setName(const char* name)
{
    strcpy(this->name,name);
}

int Character::getID() const
{
    return 1;
}
Character::~Character()
{
    delete [] this->name;
}
