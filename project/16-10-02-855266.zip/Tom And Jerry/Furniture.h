#include "Object.h"

class Furniture : public Object
{
private:
    string description;
public:
    Furniture();
    Furniture(const char*,int,int,string);
    Furniture(const Furniture&);
    Furniture& operator=(const Furniture&);
    string getDescription() const;
    void setDescription(string);
    int getID() const;
    ~Furniture();
};
