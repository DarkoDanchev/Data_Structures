#pragma once

#include "Object.h"

using namespace std;

class Position
{
private:
    Object* object; //this is pointer to object not an array of objects
public:
    Position();
    Position(Object*);
    Position(const Position&);
    Position& operator=(const Position&);
    bool isAvalible() const;
    Object* getObject() const;
    ~Position();
};
