#include "Position.h"

Position::Position()
{
    this->object = NULL;
}
Position::Position(Object* object)
{
    this->object = object;
}
Position::Position(const Position& position)
{
    this->object = position.getObject();
}
Position& Position::operator=(const Position& position)
{
    if(this != &position)
    {
        delete this->object;
        this->object = position.getObject();
    }

    return *this;
}

//the getter for the object
Object* Position::getObject() const
{
    return this->object;
}
bool Position::isAvalible() const
{
    return this->object == NULL;
}
//the destructor
Position::~Position()
{
    delete this->object;
}
