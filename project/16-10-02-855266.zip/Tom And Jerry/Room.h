#include "Position.h"

class Room
{
private:
    int widght,height;
    Position** positions; //this is two dimensional array of positions
    void copy(const Room&);
public:
    Room();
    Room(int,int,Position**);
    Room(const Room&);
    Room& operator=(const Room&);

    int getWidght() const;
    int getHeight() const;
    Position getPosition(int,int) const;

    void setWidght(int);
    void setHeight(int);
    void setPositon(Position,int,int);

    ~Room();

};
