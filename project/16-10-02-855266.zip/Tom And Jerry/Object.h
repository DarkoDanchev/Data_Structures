#pragma once

#include <cstring>
#include <string>

using namespace std;

class Object
{
private:
    char* type;
    //the position of the object
    int x , y;

public:
    Object();
    Object(const char*,int,int);
    Object(const Object&);
    Object& operator=(const Object&);
    const char* getType() const;
    int getX() const;
    int getY() const;
    void setType(const char*);
    void setX(int);
    void setY(int);
    void setPosition(int , int);
    virtual int getID() const = 0;
    virtual ~Object() = 0;
protected:
    void copy(const Object&);

};
